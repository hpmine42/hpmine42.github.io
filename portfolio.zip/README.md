# hpmine42.github.io

Portfolio of Jakob. Single page, two projects: **enough.** and **Aiko**.

Live: <https://hpmine42.github.io/>

Built with Vue 3 (Composition API, `<script setup lang="ts">`), strict TypeScript and Vite.
No backend, no analytics, no tracking. Fonts are bundled at build time, so the site does not
depend on any third-party host at runtime.

---

## Design

| | |
| --- | --- |
| Surfaces | Graphite ink `#0f100d`, bone type `#ece9e1` |
| Accent | Signal `#ff5a2c`: caret, the period in *enough.*, focus rings |
| Type | Schibsted Grotesk (display and text), JetBrains Mono (labels, code, data) |
| Scenes | The page surface changes as each project reaches the centre of the viewport: ink for the opening, paper for enough., ink with amber for Aiko |

**Hero.** The name set at poster scale with a blinking caret. Behind it, a grid of points;
under a slow lens the points turn into shifting characters. The lens follows the pointer and
drifts on its own on touch devices.

**enough.** A paper scene. One line shows the idea of end-to-end encryption: the message is
readable on both ends, the server only sees noise. A spec sheet lists what the project does and
what it leaves out.

**Aiko.** An ink scene with amber. The title is set in mono, next to a real piece of Aiko rule
code. An interactive trace replays how Aiko's engine walks its fixed stage order until one stage
answers. Sample messages and the stage order come from the Aiko README.

### Motion and accessibility

- Every animation respects `prefers-reduced-motion`: the glyph field renders a single still
  frame, typography appears without movement, scene changes are instant, the trace jumps
  straight to the answer.
- The canvas animation pauses when the hero is off-screen or the tab is hidden.
- Skip link, semantic landmarks, `aria-current` for the active section, visible focus rings,
  `aria-pressed` on the trace buttons and a polite live region for the trace result.
- Text and interface sizes never go below 14px. Body contrast is above WCAG AA on every scene.
- `overflow-x: clip` on the body and `minmax(0, 1fr)` grids prevent horizontal overflow.

---

## Requirements

- Node.js `20.19+` or `22.12+` (see `.nvmrc`)
- npm

## Install

```bash
npm install
```

Commit the generated `package-lock.json`. The deploy workflow uses `npm ci` when a lockfile is
present and falls back to `npm install` otherwise.

## Develop

```bash
npm run dev
```

Vite prints the local URL (default `http://localhost:5173/`).

## Type-check

```bash
npm run typecheck
```

Runs `vue-tsc` against the app (`tsconfig.app.json`) and the Vite config (`tsconfig.node.json`).

## Build

```bash
npm run build
```

Type-checks, then writes the static site to `dist/`.

## Preview the build

```bash
npm run preview
```

---

## Deploy to GitHub Pages

The site is served from the root of `https://hpmine42.github.io/`, so `vite.config.ts` uses
`base: '/'`.

1. The repository must be named **`hpmine42.github.io`** (a GitHub user site). Any other
   repository name is served from a subpath and would need a different `base`.
2. Push this project to the `main` branch.
3. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
4. Every push to `main` runs `.github/workflows/deploy.yml`, which installs dependencies,
   type-checks, builds and publishes `dist/`. It can also be started manually from the
   **Actions** tab (`workflow_dispatch`).

The workflow uses `actions/checkout@v5`, `actions/setup-node@v5`, `actions/configure-pages@v5`,
`actions/upload-pages-artifact@v4` and `actions/deploy-pages@v4`, with the `pages: write` and
`id-token: write` permissions required by Pages deployments. No custom domain is assumed.

---

## Project structure

```text
.
├── .github/workflows/deploy.yml   Build and deploy to GitHub Pages
├── public/favicon.svg
├── src/
│   ├── App.vue                    Page composition, scene switching
│   ├── main.ts                    Entry: fonts, styles, mount
│   ├── components/
│   │   ├── SiteNav.vue            Fixed section navigation
│   │   ├── HeroSection.vue        Opening viewport
│   │   ├── GlyphField.vue         Canvas point grid with glyph lens
│   │   ├── ScrambleText.vue       Mono text that resolves from noise
│   │   ├── ProjectEnough.vue      enough. scene
│   │   ├── CipherWire.vue         Plaintext / ciphertext / plaintext line
│   │   ├── ProjectAiko.vue        Aiko scene
│   │   ├── EngineTrace.vue        Interactive stage-order trace
│   │   ├── FactList.vue           Spec list (rows / inline variants)
│   │   ├── ExternalLink.vue       Accessible outbound link
│   │   └── SiteFooter.vue
│   ├── composables/
│   │   ├── useActiveScene.ts      Section at the viewport centre
│   │   ├── useInView.ts           IntersectionObserver helper
│   │   └── usePrefersReducedMotion.ts
│   ├── data/projects.ts           All project content and links
│   ├── styles/
│   │   ├── tokens.css             Colours, type, space, motion, scenes
│   │   └── base.css               Reset, globals, focus, reduced motion
│   └── utils/glyphs.ts            Glyph set, scramble, hash
├── env.d.ts
├── index.html
├── package.json
├── tsconfig.json / tsconfig.app.json / tsconfig.node.json
└── vite.config.ts
```

## Content sources

All project copy lives in `src/data/projects.ts` and is taken from the public repositories:

- enough.: <https://github.com/hpmine42/enough>, live at <https://hpmine42.github.io/enough/>
- Aiko: <https://github.com/hpmine42/Aiko>, live at <https://hpmine42.github.io/Aiko/>

Edit that file to change wording or links; components read from it.
